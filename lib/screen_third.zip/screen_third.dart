import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';

class scThird extends StatefulWidget {
  const scThird({super.key});

  @override
  State<scThird> createState() => _scThirdState();
}

class _scThirdState extends State<scThird> {
  List<String> items = <String>[
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
  ];

  String dropdownValue = 'Item 1';
  List imageList = [
    {"id": 1, "image_path": "lib/assets/images/car.png"},
    {"id": 2, "image_path": "lib/assets/images/women.png"},
    {"id": 3, "image_path": "lib/assets/images/mechanic.png"},
  ];
  final CarouselController carouselController = CarouselController();
  int currentIndex = 0;
  bool? isChecked = false;
  List arrNames = [
    'Ramu',
    'Ramesh',
    'Nishant',
    'Vasu',
    'Sonu',
    'Naresh',
    'Monu'
  ];
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            Row(
              children: [
                Padding(
                  padding: EdgeInsets.only(left: 60, top: 10),
                  child: Container(
                    height: 70,
                    width: 70,
                    child: Image.asset("lib/assets/images/Slogo.png"),
                  ),
                ),
                Container(
                  child: Padding(
                    padding: EdgeInsets.only(left: 100, top: 10),
                    child: DropdownButton(
                      borderRadius: BorderRadius.circular(20),
                      value: dropdownValue,
                      items: items.map<DropdownMenuItem<String>>(
                        (String value) {
                          return DropdownMenuItem(
                            value: value,
                            child: Text(value),
                          );
                        },
                      ).toList(),
                      onChanged: (String? newValue) {
                        setState(() {
                          dropdownValue = newValue!;
                        });
                        dropdownValue = newValue!;
                      },
                    ),
                  ),
                ),
              ],
            ),
            Column(
              children: [
                Stack(
                  children: [
                    InkWell(
                      onTap: () {
                        print(currentIndex);
                      },
                      child: CarouselSlider(
                        items: imageList
                            .map(
                              (item) => Image.asset(
                                item['image_path'],
                                fit: BoxFit.cover,
                                width: double.infinity,
                              ),
                            )
                            .toList(),
                        carouselController: carouselController,
                        options: CarouselOptions(
                          scrollPhysics: const BouncingScrollPhysics(),
                          autoPlay: true,
                          aspectRatio: 2,
                          viewportFraction: 1,
                          onPageChanged: (index, reason) {
                            setState(() {
                              currentIndex = index;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Container(
                      width: 150,
                      child: Flexible(
                        child: CheckboxListTile(
                          side: BorderSide(color: Colors.black),
                          visualDensity: VisualDensity.compact,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          title: const Text('Filter'),
                          value: isChecked,
                          onChanged: (bool? newValue) {
                            setState(() {
                              isChecked = newValue;
                            });
                          },
                          activeColor: Colors.white,
                          checkColor: Colors.green,
                          controlAffinity: ListTileControlAffinity.leading,
                        ),
                      ),
                    ),
                    Container(
                      width: 220,
                      height: 40,
                      child: TextField(
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(30.0),
                              borderSide: BorderSide(width: 0.8)),
                          hintText: 'Search ',
                          prefixIcon: Icon(
                            Icons.search,
                            size: 30.0,
                          ),
                          suffixIcon: IconButton(
                            icon: Icon(Icons.clear),
                            onPressed: () {},
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Container(
                height: 400,
                child: Padding(
                    padding: EdgeInsets.all(5),
                    child: ListView.builder(
                      itemBuilder: (current, index) {
                        return Stack(
                          children: [
                            Container(
                              height: 100,
                              child: Card(
                                color: Colors.white,
                                elevation: 2,
                                margin: const EdgeInsets.symmetric(vertical: 2),
                                child: ListTile(
                                  title: Text(
                                    arrNames[index],
                                    style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  leading:
                                      Image.asset("lib/assets/images/loc.png"),
                                  subtitle: Text("Mechanic "),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 280),
                              child: Image.asset("lib/assets/images/Slogo.png"),
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 300, top: 60),
                              child: TextButton(
                                  onPressed: () {},
                                  child:
                                      Image.asset("lib/assets/images/add.png")),
                            ),
                          ],
                        );
                      },
                      itemCount: arrNames.length,
                      itemExtent: 100,
                    )))
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.black,
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: [
          const BottomNavigationBarItem(
            icon: Icon(
              Icons.menu,
              color: Colors.grey,
            ),
            label: 'Map',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.favorite, color: Colors.grey),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Container(
                margin: const EdgeInsets.only(bottom: 10),
                decoration: const BoxDecoration(
                  color: Colors.redAccent,
                  shape: BoxShape.circle,
                ),
                height: 40,
                width: 40,
                child: const Icon(Icons.home, color: Colors.white)),
            label: 'Search',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.notifications, color: Colors.grey),
            label: 'Notifications',
          ),
          const BottomNavigationBarItem(
            icon: Icon(Icons.person, color: Colors.grey),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
